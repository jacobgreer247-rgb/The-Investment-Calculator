/*
 * Calculator.cpp
 *
 *  Date: [August 4, 2025]
 *  Author: [Jacob Greer]
 */
#include <iostream>
#include <iomanip>
using namespace std;

class InvestmentCalculator {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterestRate;
    int numYears;

public:
    // Constructor
    InvestmentCalculator() {
        initialInvestment = 0.0;
        monthlyDeposit = 0.0;
        annualInterestRate = 0.0;
        numYears = 0;
    }

    // Function to show the user menu and gather input
    void ShowUserMenu() {
        cout << "============================\n";
        cout << "  Welcome to Airgead Banking\n";
        cout << "============================\n";
        cout << "This program shows how your investment will grow over time.\n";

        cout << "\nEnter Initial Investment Amount: $";
        cin >> initialInvestment;
        cout << "Enter Monthly Deposit: $";
        cin >> monthlyDeposit;
        cout << "Enter Annual Interest Rate (in %): ";
        cin >> annualInterestRate;
        cout << "Enter Number of Years: ";
        cin >> numYears;

        cout << "\nPress any key to continue...";
        cin.ignore();
        cin.get(); // Wait for user input
    }

    // Compute monthly interest using the formula
    double ComputeMonthlyInterest(double balance) {
        return balance * ((annualInterestRate / 100) / 12);
    }

    // Function to generate the reports
    void GenerateReports() {
        // First: Without Monthly Deposits
        double balance = initialInvestment;
        double yearlyInterest;

        cout << "\n\nBalance and Interest Without Additional Monthly Deposits" << endl;
        cout << "===========================================================" << endl;
        cout << "Year\tYear End Balance\tEarned Interest" << endl;
        cout << "-----------------------------------------------------------" << endl;

        for (int year = 1; year <= numYears; year++) {
            yearlyInterest = balance * (annualInterestRate / 100);
            balance += yearlyInterest;
            cout << year << "\t$" << fixed << setprecision(2) << balance << "\t\t$" << yearlyInterest << endl;
        }

        // Reset for monthly deposit calculation
        balance = initialInvestment;

        cout << "\n\nBalance and Interest With Additional Monthly Deposits" << endl;
        cout << "===========================================================" << endl;
        cout << "Year\tYear End Balance\tEarned Interest" << endl;
        cout << "-----------------------------------------------------------" << endl;

        for (int year = 1; year <= numYears; year++) {
            yearlyInterest = 0.0;
            for (int month = 1; month <= 12; month++) {
                double interest = ComputeMonthlyInterest(balance + monthlyDeposit);
                yearlyInterest += interest;
                balance += monthlyDeposit + interest;
            }
            cout << year << "\t$" << fixed << setprecision(2) << balance << "\t\t$" << yearlyInterest << endl;
        }
    }
};

int main() {
    InvestmentCalculator calc;
    calc.ShowUserMenu();
    calc.GenerateReports();

    cout << "\nProgram complete. Press any key to exit...";
    cin.get();
    return 0;
}
